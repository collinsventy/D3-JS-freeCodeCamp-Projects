# D3 Choropleth Map

A Pen created on CodePen.io. Original URL: [https://codepen.io/Collin-Sventy/pen/rNXMMRe](https://codepen.io/Collin-Sventy/pen/rNXMMRe).

