// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 

// US Education Data:https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/for_user_education.json
// US County Data:https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/counties.json

// External data
const educationUrl = "https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/for_user_education.json";
const countyUrl = "https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/counties.json";

// chart dimensions
const width = 1000;
const height = 700;
const margin = { top: 30, right: 30, bottom: 40, left: 60 };

// Create SVG container
const svg = d3.select("#chart")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .style("background-color", "#fafafa");

// Add header text at the top of the map
svg.append("text")
  .attr("x", width / 2) // Center the text horizontally
  .attr("y", margin.top - 10) // Position just below the top margin
  .attr("text-anchor", "middle")
  .attr("font-size", "24px")
  .attr("fill", "black")
  .text("United States Educational Attainment")
  .style("font-family", "Helvetica, sans-serif");

// Add description element
svg.append("text")
  .attr("x", width / 2)
  .attr("y", margin.top + 20) // Position just below the top margin
  .attr("id", "description")
  .attr("text-anchor", "middle")
  .attr("font-size", "16px")
  .attr("fill", "black")
  .text("This choropleth map shows the percentage of adults aged 25 and older with a bachelor's degree or higher in the United States (2010-2014).")
  .style("font-family", "Helvetica, sans-serif");



// Load both education & county data
Promise.all([
  d3.json(educationUrl),
  d3.json(countyUrl)
]).then(([eduData, countyData]) => {

  const counties = topojson.feature(countyData, countyData.objects.counties).features;
  const educationMap = new Map(eduData.map(d => [d.fips, d.bachelorsOrHigher]));

  const colorScale = d3.scaleQuantize()
    .domain(d3.extent(eduData, d => d.bachelorsOrHigher))
    .range(["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"]);

  const path = d3.geoPath();

  const mapGroup = svg.append("g")
    .attr("transform", "translate(0, 50)");
  // Draw counties with the class "county"
  mapGroup.selectAll(".county")
    .data(counties)
    .enter()
    .append("path")
    .attr("data-fips", d => String(d.id))
    .attr("data-education", d => educationMap.get(d.id) || 0)
    .attr("class", "county")  // Use the required class name
    .attr("d", path)
    .attr("fill", d => {
      const eduLevel = educationMap.get(d.id);
      return eduLevel ? colorScale(eduLevel) : "#ccc";
    })
    .on("mouseover", (event, d) => {
      const fipsCode = d.id;
      const countyData = eduData.find(item => item.fips === fipsCode);
      const eduLevel = countyData ? countyData.bachelorsOrHigher : "N/A";
      const countyName = countyData ? countyData.area_name : "Unknown County";  
    
    const tooltip = d3.select("#tooltip");

      // Set tooltip's data-education attribute
      tooltip.attr("data-education", eduLevel)
        .style("opacity", 0.9)
        .style("left", (event.pageX + 5) + "px")
        .style("top", (event.pageY - 28) + "px")
        .text(`${countyName}, Education: ${eduLevel}%`);
    })
    .on("mouseout", () => {
      d3.select("#tooltip")
        .style("opacity", 0);
    });

  // Draw state borders for clarity
  mapGroup.append("path")
    .datum(topojson.mesh(countyData, countyData.objects.states, (a, b) => a !== b))
    .attr("class", "state")
    .attr("fill", "none")
    .attr("stroke", "#333")
    .attr("stroke-width", "1")
    .attr("d", path);

  // Create legend
  const legendWidth = 300;
  const legendHeight = 10;

  const legend = svg.append("g")
    .attr("id", "legend")
    .attr("transform", `translate(${width - legendWidth - 20}, ${height - 40})`);

  // Define legend scale
  const legendScale = d3.scaleLinear()
    .domain(colorScale.domain())
    .range([0, legendWidth]);

  // Define legend axis
  const legendAxis = d3.axisBottom(legendScale)
    .tickSize(legendHeight)
    .ticks(7)
    .tickFormat(d => `${Math.round(d)}%`);

  // Add color gradient for legend
  legend.selectAll("rect")
    .data(colorScale.range().map(color => {
      const d = colorScale.invertExtent(color);
      return [d[0] || legendScale.domain()[0], d[1] || legendScale.domain()[1]];
    }))
    .enter().append("rect")
    .attr("x", d => legendScale(d[0]))
    .attr("width", d => legendScale(d[1]) - legendScale(d[0]))
    .attr("height", legendHeight)
    .style("fill", d => colorScale(d[0]));

  // Add axis to legend
  legend.append("g")
    .call(legendAxis)
    .select(".domain")
    .remove(); // Remove the axis line for a cleaner look
  
  legend.selectAll(".tick line")
  .style("opacity", 0);
  
  // Add text above the legend
svg.append("text")
  .attr("x", width - 300) // Adjust x to position horizontally above legend
  .attr("y", height - 50) // Adjust y to position just above the legend
  .attr("text-anchor", "right")
  .attr("font-size", "14px")
  .attr("fill", "black")
  .text("Percentage of adults with Bachelor's degree or higher")
  .style("font-family: Helvetica, sans-serif");
  

});
