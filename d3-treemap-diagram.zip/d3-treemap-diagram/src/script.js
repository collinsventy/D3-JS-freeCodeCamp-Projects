// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 


const width = 1000;
const height = 1000;

// Create SVG container
const svg = d3.select("#treemap")
  .append("svg")
  .attr("width", width)
  .attr("height", height);

// Load kickstarter data
d3.json("https://cdn.freecodecamp.org/testable-projects-fcc/data/tree_map/kickstarter-funding-data.json").then(data => {
       

// Create a root node for hierarchy layout
const root = d3.hierarchy(data)
  .sum(d => d.value)
  .sort((a, b) => b.value - a.value);

// Set up treemap layout
d3.treemap()
  .size([width, height])
  .padding(1)(root);

// Define a color scale with two colors
const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

// Bind data and create <rect> elements with class="tile"
svg.selectAll("rect")
  .data(root.leaves())
  .enter()
  .append("rect")
  .attr("class", "tile")
  .attr("x", d => d.x0)
  .attr("y", d => d.y0)
  .attr("width", d => d.x1 - d.x0)
  .attr("height", d => d.y1 - d.y0)
  .style("fill", d => colorScale(d.data.category)) // Color Scale for fill
  .attr("data-name", d => d.data.name) // Set data-name attribute
  .attr("data-category", d => d.data.category) // Example for data-cat attr
  .attr("data-value", d => d.data.value) // Set data-value attr
// tooltip
  .on("mouseover", function (event, d) {
    d3.select("#tooltip")
      .style("visibility", "visible")
      .attr("data-value", d.data.value) // FCC test cases
      .html(`Name: ${d.data.name}<br>Category: ${d.data.category}<br>Value: ${d.data.value}`);
  })
  .on("mousemove", function (event) {
    d3.select("#tooltip")
      .style("top", (event.pageY + 10) + "px") // adjust for cursor offset
      .attr("left", (event.pageX + 10) + "px");  
  })
  .on("mouseout", function () {
    d3.select("#tooltip").style("visibility", "hidden");
  });
  
  // Add foreignObject for text labels within each square
  svg.selectAll("foreignObject")
    .data(root.leaves())
    .enter()
    .append("foreignObject")
    .attr("x", d => d.x0)
    .attr("y", d => d.y0)
    .attr("width", d => d.x1 - d.x0)
    .attr("height", d => d.y1 - d.y0)
    .append("xhtml:div")
    .style("font-size", "10px")
    .style("font-family", "Arial")
    .style("color", "white")
    .style("word-wrap", "break-word") // Enable wrapping
    .style("overflow", "hidden") // Hide overflow
    .style("height", "100%") // Ensure full heigh of div is used
    .text(d => d.data.name);
  
// Optional: Add text labels for each tile
//svg.selectAll("text")
  //        .data(root.leaves())
    //      .enter()
      //    .append("text")
        //  .attr("x", d => d.x0 + 5)
 //         .attr("y", d => d.y0 + 20)
   //       .text(d => d.data.name)
     //     .attr("font-size", "10px")
       //   .attr("fill", "white");

  // Define unique categories for the legend
  const categories = root.leaves().map(d => d.data.category).filter((v, i, s) => s.indexOf(v) === i);

  
// Create legend with three columns
  const legendWidth = 400;
  const legendItemWidth = 130; // width for each item
  const legendItemHeight = 25; // height for each item
  const legendX = 0; // center the legend based on chart width
  
  //  const legendX = (width - legendWidth) / 2; // center the legend based on chart width
  
// const categories = root.leaves().map(d => d.data.category).filter((v, i, s) => s.indexOf(v) === i);
const legend = d3.select("#legend")
  .append("svg")
  .attr("width", legendWidth)
  .attr("height", Math.ceil(categories.length / 3) * legendItemHeight)
  .attr("transform", `translate(${legendX}, ${height - 1000})`);
  
  // .attr("transform", `translate(${legendX}, ${height - 950})`);

  // legend item with proper positioning
legend.selectAll("rect")
  .data(categories)
  .enter()
  .append("rect")
  .attr("class", "legend-item") // add class here for each legend <rect>
  .attr("x", (d, i) => (i % 3) * legendItemWidth + 10) // calc x based on column
  .attr("y", (d, i) => Math.floor(i / 3) * legendItemHeight) // Calc y based on row
  .attr("width", 20)
  .attr("height", 20)
  .style("fill", d => colorScale(d));

legend.selectAll("text")
  .data(categories)
  .enter()
  .append("text")
  .attr("x", (d, i) => (i % 3) * legendItemWidth + 35) // Adjust for text posit
  .attr("y", (d, i) => Math.floor(i / 3) * legendItemHeight + 15) // Align text with rectangles
  .text(d => d)
  .style("font-size", "12px")
  .style("font-family", "Arial")
  .attr("fill", "black");
});