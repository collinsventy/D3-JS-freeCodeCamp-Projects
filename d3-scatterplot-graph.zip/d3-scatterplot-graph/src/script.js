// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 

// Load external data
const dataUrl = "https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/cyclist-data.json";

// Set chart dimensions
const width = 800;
const height = 400;
const margin = { top: 30, right: 30, bottom: 40, left: 60 };

// Create the SVG container
const svg = d3.select("#chart")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .style("background-color", "#fafafa");

// Create title for chart
svg.append("text")
  .attr("x", width / 2) // Center title
  .attr("y", margin.top-10) // Position above chart
  .attr("text-anchor", "middle") // Center the text
  .attr("font-size", "20px") // Font size for title
  .attr("fill", "black") // Color of the title
  .text("Doping in Professional Bicycle Racing"); // Desired title

// Load data
d3.json(dataUrl).then(data => {
  // Parsing the dataset
  const dataset = data.map(d => ({
    x: new Date(d.Year, 0), // Create Date object from year
    y: new Date(1970, 0, 1, 0, d.Seconds / 60, d.Seconds % 60), // Create Date object from seconds
    name: d.Name,
    doping: d.Doping
  }));

  // Create scales
  const xScale = d3.scaleTime()
    .domain(d3.extent(dataset, d => d.x)) // Use range of dates (year)
    .range([margin.left, width - margin.right]);

  const yScale = d3.scaleTime()
    .domain(d3.extent(dataset, d => d.y)) // Use range of time (minutes)
    .range([height - margin.bottom, margin.top]);

  // Create the x-axis
  const xAxis = d3.axisBottom(xScale);
  svg.append("g")
    .attr("id", "x-axis")
    .attr("transform", `translate(0, ${height - margin.bottom})`)
    .call(xAxis)
    .append("text")
    .attr("fill", "black")
    .attr("x", width / 2)
    .attr("y", margin.bottom - 10)
    .attr("text-anchor", "middle")
    .text("Year");

  // Create the y-axis
  const yAxis = d3.axisLeft(yScale).tickFormat(d3.timeFormat("%M:%S"));
  svg.append("g")
    .attr("id", "y-axis")
    .attr("transform", `translate(${margin.left}, 0)`)
    .call(yAxis)
    .append("text")
    .attr("fill", "black")
    .attr("x", -height / 2)
    .attr("y", -40)
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(-90)")
    .text("Time in Minutes");

  // Add points (scatterplot circles)
  svg.selectAll(".dot")
    .data(dataset)
    .enter()
    .append("circle")
    .attr("class", "dot")
    .attr("cx", d => xScale(d.x))
    .attr("cy", d => yScale(d.y))
    .attr("r", 5)
    .attr("fill", d => d.doping ? "red" : "green")
    .attr("data-xvalue", d => d.x.getFullYear())
    .attr("data-yvalue", d => d.y.toISOString());

  // Tooltip setup
  const tooltip = d3.select("#tooltip");

  svg.selectAll(".dot")
    .on("mouseover", (event, d) => {
      tooltip.transition()
        .duration(200)
        .style("opacity", 0.9);

      tooltip.html(`
        Name: ${d.name}<br/>
        Year: ${d.x.getFullYear()}<br/>
        Time: ${d3.timeFormat("%M:%S")(d.y)}<br/>
        Doping: ${d.doping ? d.doping : "None"}
      `)
      .style("left", (event.pageX + 5) + "px")
      .style("top", (event.pageY - 28) + "px")
      .attr("data-year", d.x.getFullYear());
    })
    .on("mouseout", () => {
      tooltip.transition()
        .duration(500)
        .style("opacity", 0);
    });

  // Define Legend Data
  const legendData = [
    { color: "green", label: "No Doping" },
    { color: "red", label: "Doping"}
  ];
  
  // Create a group for the legend
const legend = svg.append("g")
  .attr("id", "legend")
  .attr("transform", `translate(${width / 2 + 200}, ${height - margin.bottom - 200})`); // Centered horizontally
 // Centered vertically on the right side

 // Centered horizontally

   // .attr("transform", `translate(${width - margin.right + 10}, ${margin.top})`); // Corrected position
  
  // Append legend items
  legendData.forEach((d, i) => {
    // Colored rect for each category
    legend.append("rect")
      .attr("x", 0) // X position
      .attr("y", i * 20) // Y position based on index
      .attr("width", 15) // Width of rect
      .attr("height", 15) // Height of rect
      .attr("fill", d.color); // Color of rect
    
    // Add text labels next to rect
    legend.append("text")
      .attr("x", 20) // Position text to right of rect
      .attr("y", i * 20 + 12) // Center text vertically
      .text(d.label); // Text for legend
  });

  console.log("X Scale Domain:", xScale.domain());
  console.log("X Scale Range:", xScale.range());
  console.log(`Legend Position - X: ${width - margin.right - 20}, Y: ${height / 2 - (legendItems * 20) / 2}`);

});
