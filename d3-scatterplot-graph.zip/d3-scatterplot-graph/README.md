# D3 Scatterplot Graph

A Pen created on CodePen.io. Original URL: [https://codepen.io/Collin-Sventy/pen/qBebVzj](https://codepen.io/Collin-Sventy/pen/qBebVzj).

