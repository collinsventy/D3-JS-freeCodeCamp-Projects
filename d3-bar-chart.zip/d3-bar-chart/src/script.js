// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 

// Load the external data
const dataUrl = "https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/GDP-data.json";

// Set chart dimensions
const width = 800;
const height = 400;
const margin = { top: 20, right: 30, bottom: 40, left: 60 };

// Create the SVG container
const svg = d3.select("#chart")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .style("background-color", "#fafafa");

// Load the data
d3.json(dataUrl).then(data => {
  const dataset = data.data;

  // Parse the dates and create scales
  const parseDate = d3.timeParse("%Y-%m-%d");
  dataset.forEach(d => {
    d[0] = parseDate(d[0]); // Convert date strings to Date objects
  });

  const xScale = d3.scaleTime()
    .domain(d3.extent(dataset, d => d[0]))  // Use the range of dates
    .range([margin.left, width - margin.right]);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, d => d[1])])  // Use the second value (GDP)
    .range([height - margin.bottom, margin.top]);

  // Append the X-axis
  svg.append("g")
    .attr("id", "x-axis")
    .attr("transform", `translate(0,${height - margin.bottom})`)
    .call(d3.axisBottom(xScale)
      .ticks(d3.timeYear.every(5)) // Show every 5 years
      .tickFormat(d3.timeFormat("%Y"))); // Format ticks to show year only

  // Append the Y-axis
  svg.append("g")
    .attr("id", "y-axis")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(yScale));

  // Create bars with custom attributes for date and GDP
  const tooltip = d3.select("#tooltip");

  svg.selectAll(".bar")
    .data(dataset)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("x", d => xScale(d[0])) // Use date for x position
    .attr("y", d => yScale(d[1]))
    .attr("width", (width - margin.left - margin.right) / dataset.length - 1) // Adjust width for visibility
    .attr("height", d => height - margin.bottom - yScale(d[1]))
    .attr("fill", "steelblue")
    // Add custom attributes for date and GDP
    .attr("data-date", d => d[0].toISOString().split("T")[0]) // Format date for attribute
    .attr("data-gdp", d => d[1])  // Second element is the GDP value
    .on("mouseover", (event, d) => {
      tooltip.transition()
        .duration(200)
        .style("opacity", 0.9); // Show tooltip

      tooltip.html(`Date: ${d[0].toISOString().split("T")[0]}<br/>GDP: $${d[1].toLocaleString()}`)
    .attr("fill", "green")
        .style("left", (event.pageX + 5) + "px") // Position tooltip
        .style("top", (event.pageY - 28) + "px")
        .attr("data-date", d[0].toISOString().split("T")[0]); // Set data-date attribute
    })
    .on("mouseout", () => {
      tooltip.transition()
        .duration(500)
        .style("opacity", 0); // Hide tooltip
    });
});

// Create title for the chart
svg.append("text")
  .attr("x", width / 2) // Center the title
  .attr("y", margin.top) // Position it above the chart
  .attr("text-anchor", "middle") // Center the text
  .attr("font-size", "30px") // Font size for the title
  .attr("fill", "black") // Color of the title
  .text("United States GDP Over Time"); // Your desired title