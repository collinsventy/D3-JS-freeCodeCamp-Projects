// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 
const dataUrl = "https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/global-temperature.json";

// Set chart dimensions
const width = 800;
const height = 400;
const margin = { top: 100, right: 60, bottom: 100, left: 60 };

// Create the SVG container
const svg = d3.select("#chart")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .style("background-color", "#fafafa");

// Load the data
d3.json(dataUrl).then(data => {
  const baseTemperature = data.baseTemperature;
  const dataset = data.monthlyVariance;

  // Create scales
  const xScale = d3.scaleTime()
    .domain(d3.extent(dataset, d => new Date(d.year, 0)))
    .range([margin.left, width - margin.right]);

  const yScale = d3.scaleBand()
    .domain(d3.range(0, 12)) // Corrected months range to 0-11
    .range([margin.top, height - margin.bottom])
    .padding(0.1);

  const colorScale = d3.scaleLinear()
    .domain([d3.min(dataset, d => d.variance), -1, 0, 1, d3.max(dataset, d => d.variance)]) // Set domain with values for nine colors
    .range([
      "blue", "lightblue", "green", "yellow", "orange", "red", "darkred", "violet", "purple"
    ]);

  // Append the X-axis
  svg.append("g")
    .attr("id", "x-axis")
    .attr("transform", `translate(0, ${height - margin.bottom})`) // Fixed here
    .call(d3.axisBottom(xScale).ticks(d3.timeYear.every(10)).tickFormat(d3.timeFormat("%Y")));

  // Append the Y-axis (Months)
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  svg.append("g")
    .attr("id", "y-axis")
    .attr("transform", `translate(${margin.left}, 0)`) // Fixed here
    .call(d3.axisLeft(yScale).tickFormat((d, i) => months[i]));

  // Create the heat map
  svg.selectAll(".cell")
    .data(dataset)
    .enter()
    .append("rect")
    .attr("class", "cell")
    .attr("x", d => xScale(new Date(d.year, 0))) // Map the year to the x-axis
    .attr("y", d => yScale(d.month - 1)) // Adjust month indexing to 0-11
    .attr("width", (width - margin.left - margin.right) / (dataset.length / 12)) // Cell width
    .attr("height", yScale.bandwidth()) // Cell height
    .attr("fill", d => colorScale(d.variance)) // Fill color based on temperature variance
    // Add tooltip data attributes
    .attr("data-year", d => d.year)
    .attr("data-month", d => d.month - 1)  // Adjust month for 0-indexed months
    .attr("data-temp", d => baseTemperature + d.variance)
    .on("mouseover", (event, d) => {
      const tooltip = d3.select("#tooltip");
      tooltip.transition()
        .duration(200)
        .style("opacity", 0.9); // Show tooltip

      tooltip.html(`Year: ${d.year}<br/>Month: ${months[d.month - 1]}<br/>Temp: ${(baseTemperature + d.variance).toFixed(2)}℃<br/>Variance: ${d.variance.toFixed(2)}℃`) // Fixed here
        .style("left", (event.pageX + 5) + "px")
        .style("top", (event.pageY - 28) + "px")
        .attr("data-year", d.year);
    })
    .on("mouseout", () => {
      d3.select("#tooltip").transition()
        .duration(500)
        .style("opacity", 0);
    });

  // Create title for the chart
  svg.append("text")
    .attr("x", width / 2) // Center the title
    .attr("y", margin.top - 30) // Position it above the chart
    .attr("text-anchor", "middle") // Center the text
    .attr("font-size", "30px") // Font size for the title
    .attr("fill", "black") // Color of the title
    .text("Monthly Global Land-Surface Temperature");

  // Subtitle for the chart (beneath the title)
  svg.append("text")
    .attr("id", "description")
    .attr("x", width / 2) // Center the subtitle
    .attr("y", margin.top) // Position it slightly below the title
    .attr("text-anchor", "middle") // Center the text
    .attr("font-size", "20px") // Font size for the subtitle
    .attr("fill", "gray") // Color of the subtitle
    .text("1753 - 2015: base temperature 8.66℃");

  // Legend details
  const legendWidth = 20;
  const legendHeight = 20;
  const legendMargin = 50;

  // Create a group for the legend
  const legend = svg.append("g")
    .attr("id", "legend")
    .attr("transform", `translate(${(width - (legendMargin * 9)) / 2 - 40}, ${height - margin.bottom + 21})`); // Fixed here

  // Legend rectangles
  legend.selectAll(".legend-rect")
    .data([2.8, 3.9, 5.0, 6.1, 7.2, 8.3, 9.5, 10.6, 11.7, 12.8]) // Using actual values for the legend
    .enter()
    .append("rect")
    .attr("class", "legend-rect")
    .attr("x", (d, i) => legendMargin * i)
    .attr("y", 0)
    .attr("width", legendMargin)
    .attr("height", legendHeight)
    .attr("fill", d => colorScale(d - baseTemperature));

  // Add labels to the legend
  legend.selectAll(".legend-label")
    .data([2.8, 3.9, 5.0, 6.1, 7.2, 8.3, 9.5, 10.6, 11.7, 12.8])
    .enter()
    .append("text")
    .attr("class", "legend-label")
    .attr("x", (d, i) => i * legendMargin + legendMargin / 2) // Position the text in the middle of each rectangle
    .attr("y", legendHeight + 25) // Move the text slightly below the rectangles
    .attr("text-anchor", "middle") // Center the text
    .text(d => d); // Display the corresponding temperature value
});
